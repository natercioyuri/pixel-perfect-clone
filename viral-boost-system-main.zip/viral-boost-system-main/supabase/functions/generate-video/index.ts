import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const BASE_URL = "https://generativelanguage.googleapis.com/v1beta";

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get("GOOGLE_AI_STUDIO_API_KEY");
    if (!apiKey) {
      return new Response(JSON.stringify({ error: "GOOGLE_AI_STUDIO_API_KEY not configured" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { action, prompt, image, operationName } = await req.json();

    // Poll for result
    if (action === "poll") {
      if (!operationName) {
        return new Response(JSON.stringify({ error: "operationName required for polling" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const pollResp = await fetch(
        `${BASE_URL}/${operationName}`,
        {
          method: "GET",
          headers: { "x-goog-api-key": apiKey },
        }
      );
      const pollData = await pollResp.json();

      if (!pollResp.ok) {
        console.error("Poll error:", pollData);
        return new Response(JSON.stringify({ error: "Polling failed", details: pollData }), {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      if (pollData.done) {
        const videos = pollData.response?.generatedSamples || pollData.response?.videos || [];
        const video = videos[0];
        const videoUri = video?.video?.uri || null;

        if (videoUri) {
          // Download video bytes and return as base64
          const videoResp = await fetch(videoUri, {
            headers: { "x-goog-api-key": apiKey },
          });
          if (videoResp.ok) {
            const arrayBuffer = await videoResp.arrayBuffer();
            const uint8 = new Uint8Array(arrayBuffer);
            let binary = "";
            for (let i = 0; i < uint8.length; i++) {
              binary += String.fromCharCode(uint8[i]);
            }
            const base64 = btoa(binary);
            return new Response(
              JSON.stringify({ done: true, videoBase64: base64, mimeType: "video/mp4" }),
              { headers: { ...corsHeaders, "Content-Type": "application/json" } }
            );
          }
        }

        // Log raw response for debugging
        console.log("Veo poll response:", JSON.stringify(pollData.response));

        return new Response(
          JSON.stringify({ done: true, videoBase64: null, error: "No video generated", rawResponse: pollData.response }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      return new Response(
        JSON.stringify({ done: false }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Start generation
    if (!prompt) {
      return new Response(JSON.stringify({ error: "prompt is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const instances: any = { prompt };

    // If image provided (base64), add it as a reference image
    if (image) {
      instances.image = {
        bytesBase64Encoded: image.data,
        mimeType: image.mimeType || "image/jpeg",
      };
    }

    const body = {
      instances: [instances],
      parameters: {
        aspectRatio: "16:9",
        durationSeconds: 8,
      },
    };

    const model = "veo-3.0-generate-001";
    const genResp = await fetch(
      `${BASE_URL}/models/${model}:predictLongRunning`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": apiKey,
        },
        body: JSON.stringify(body),
      }
    );

    const genData = await genResp.json();

    if (!genResp.ok) {
      console.error("Generation error:", genData);
      return new Response(JSON.stringify({ error: "Video generation failed", details: genData }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(
      JSON.stringify({ operationName: genData.name }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (e) {
    console.error("generate-video error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
