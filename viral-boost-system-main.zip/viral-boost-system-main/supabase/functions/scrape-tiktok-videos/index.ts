import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface AIExtractedVideo {
  video_url: string;
  title: string;
  creator_name: string | null;
  thumbnail_url: string | null;
  views: number | null;
  likes: number | null;
  shares: number | null;
  comments: number | null;
  hashtags: string[];
  posted_at: string | null;
  product_name: string | null;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const openrouterKey = Deno.env.get("OPENROUTER_API_KEY");
    const lovableKey = Deno.env.get("LOVABLE_API_KEY");

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    console.log("Starting AI-powered video scraping");

    const allVideos: AIExtractedVideo[] = [];

    // Rotate queries to get fresh diverse results each time
    const allQueries = [
      "TikTok viral products video trending this week 2026 tiktokmademebuyit",
      "vídeos virais TikTok produtos mais vistos hoje Brasil",
      "TikTok Shop viral video creators trending now with views likes",
      "newest trending TikTok product videos most popular today",
      "TikTok viral video products beauty gadgets trending right now",
      "melhores vídeos TikTok Shop virais semana produtos tendência",
      "top TikTok product videos going viral this month highest views",
      "TikTok Shop best selling products viral video new trending",
    ];

    // Pick 2 random queries each run to save credits
    const shuffled = allQueries.sort(() => Math.random() - 0.5);
    const searchQueries = shuffled.slice(0, 2);
    console.log("Using queries:", searchQueries);

    for (const query of searchQueries) {
      try {
        let searchResults: { url: string; content: string }[] = [];
        if (openrouterKey) {
          searchResults = await searchWithPerplexitySonar(openrouterKey, query);
        }
        if (searchResults.length === 0) {
          searchResults = await searchWithGoogleCSE(query);
        }
        if (searchResults.length > 0) {
          for (const result of searchResults) {
            const extracted = await extractVideosWithAI(lovableKey, result.content, result.url);
            allVideos.push(...extracted);
          }
        }
      } catch (err) {
        console.error("Search error:", err);
      }
    }

    const uniqueVideos = deduplicateVideos(allVideos);
    console.log(`AI extracted ${uniqueVideos.length} valid unique videos`);

    let upsertedCount = 0;
    for (const video of uniqueVideos) {
      let storedThumbnail = video.thumbnail_url;
      
      // Try to download existing thumbnail
      if (video.thumbnail_url) {
        const stored = await downloadToStorage(supabase, supabaseUrl, video.thumbnail_url, "thumbnails");
        if (stored) storedThumbnail = stored;
      }
      
      // If no thumbnail, search for one via Google CSE
      if (!storedThumbnail && uniqueVideos.indexOf(video) < 5) {
        const searchQuery = video.creator_name 
          ? `${video.creator_name} TikTok video thumbnail` 
          : `${video.title} TikTok video`;
        const imageUrl = await searchImageWithGoogleCSE(searchQuery);
        if (imageUrl) {
          const stored = await downloadToStorage(supabase, supabaseUrl, imageUrl, "thumbnails");
          if (stored) storedThumbnail = stored;
        }
      }

      const views = video.views || 0;
      const likes = video.likes || 0;
      const shares = video.shares || 0;
      const trendingScore = calcScore(views, likes, shares);

      const { error } = await supabase.from("viral_videos").upsert(
        {
          video_url: video.video_url,
          title: video.title,
          creator_name: video.creator_name,
          creator_avatar: null,
          thumbnail_url: storedThumbnail,
          views,
          likes,
          shares,
          comments: video.comments || 0,
          revenue_estimate: estimateRevenue(views, likes),
          hashtags: video.hashtags.length > 0 ? video.hashtags : ["#tiktok", "#viral"],
          trending_score: trendingScore,
          posted_at: video.posted_at,
          product_name: video.product_name,
        },
        { onConflict: "video_url" }
      );

      if (error) {
        console.error("Upsert error:", error.message);
      } else {
        upsertedCount++;
      }
    }

    // Also recalculate scores for existing videos that weren't in this batch
    // to decay old trending scores slightly (so stale videos drop in ranking)
    try {
      const { data: oldVideos } = await supabase
        .from("viral_videos")
        .select("id, trending_score, created_at")
        .order("trending_score", { ascending: false })
        .limit(50);

      if (oldVideos) {
        const now = Date.now();
        for (const v of oldVideos) {
          const ageMs = now - new Date(v.created_at).getTime();
          const ageDays = ageMs / (1000 * 60 * 60 * 24);
          // Apply decay: reduce score by 5% per day for videos older than 2 days
          if (ageDays > 2 && v.trending_score > 0) {
            const decayFactor = Math.max(0.3, 1 - (ageDays - 2) * 0.05);
            const newScore = Math.round(v.trending_score * decayFactor * 10) / 10;
            if (newScore < v.trending_score) {
              await supabase
                .from("viral_videos")
                .update({ trending_score: newScore })
                .eq("id", v.id);
            }
          }
        }
        console.log("Applied trending score decay to old videos");
      }
    } catch (err) {
      console.error("Score decay error:", err);
    }

    return new Response(
      JSON.stringify({
        success: true,
        message: `Scraped and saved ${upsertedCount} videos`,
        total_found: uniqueVideos.length,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error in scrape-tiktok-videos:", error);
    return new Response(
      JSON.stringify({ success: false, error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

// ─── Google CSE Search Engine ───

async function searchWithGoogleCSE(query: string): Promise<{ url: string; content: string }[]> {
  const cseKey = Deno.env.get("GOOGLE_CSE_API_KEY");
  const cseCx = Deno.env.get("GOOGLE_CSE_CX");
  if (!cseKey || !cseCx) return [];

  try {
    const q = encodeURIComponent(query);
    const url = `https://www.googleapis.com/customsearch/v1?key=${cseKey}&cx=${cseCx}&q=${q}&num=5`;
    const res = await fetch(url);
    if (!res.ok) {
      console.error("Google CSE error:", res.status);
      return [];
    }
    const data = await res.json();
    const items = data.items || [];
    if (items.length === 0) return [];

    const content = items.map((item: any) => 
      `${item.title}\n${item.snippet || ""}\n${item.link}`
    ).join("\n\n");
    
    console.log(`Google CSE found ${items.length} results for "${query}"`);
    return [{ url: "google-cse-search", content }];
  } catch (err) {
    console.error("Google CSE error:", err);
    return [];
  }
}

// ─── Search Engine ───

interface SearchResult {
  url: string;
  content: string;
}

async function searchWithPerplexitySonar(apiKey: string, query: string): Promise<SearchResult[]> {
  try {
    const res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        "HTTP-Referer": "https://lovable.dev",
      },
      body: JSON.stringify({
        model: "perplexity/sonar",
        max_tokens: 1500,
        messages: [
          {
            role: "system",
            content: `You are a research assistant for TikTok viral videos. Search for REAL TikTok videos that are currently going viral.

For each video provide:
- The EXACT TikTok video URL (format: https://www.tiktok.com/@username/video/1234567890)
- Video title or description
- Creator username (@handle)
- View count, likes, shares, comments (as numbers)
- Hashtags used
- Product name if the video promotes a product
- When it was posted

IMPORTANT:
- Only include videos with REAL TikTok URLs (tiktok.com/@user/video/ID)
- Focus on videos trending RIGHT NOW, not old content
- Include variety: different creators, different products, different niches
- Include estimated engagement metrics even if approximate`,
          },
          { role: "user", content: query },
        ],
      }),
    });

    if (!res.ok) {
      console.error("Perplexity Sonar error:", res.status, await res.text());
      return [];
    }

    const data = await res.json();
    const content = data.choices?.[0]?.message?.content || "";
    if (!content || content.length < 30) return [];

    return [{ url: "perplexity-sonar-search", content }];
  } catch (err) {
    console.error("Perplexity Sonar error:", err);
    return [];
  }
}

// ─── AI Extraction ───

async function extractVideosWithAI(apiKey: string | undefined, markdown: string, sourceUrl: string): Promise<AIExtractedVideo[]> {
  if (!apiKey) return extractVideosFallback(markdown, sourceUrl);

  try {
    const truncated = markdown.substring(0, 5000);
    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          {
            role: "system",
            content: `You extract TikTok video data from web content. Return data through the tool call.

Each video MUST have a valid TikTok URL (tiktok.com/@username/video/ID format).
Skip any entry without a real TikTok video URL.

Extract: video_url, title (max 120 chars), creator_name (@handle), thumbnail_url, views (number), likes (number), shares (number), comments (number), hashtags (array of strings), posted_at (ISO date or null), product_name (product being promoted or null).

Convert text metrics to numbers: "267K" = 267000, "1.2M" = 1200000.
Max 10 videos per response.`,
          },
          {
            role: "user",
            content: `Extract TikTok videos from:\n\n${truncated}`,
          },
        ],
        tools: [{
          type: "function",
          function: {
            name: "extract_videos",
            description: "Extract structured TikTok video data",
            parameters: {
              type: "object",
              properties: {
                videos: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      video_url: { type: "string" },
                      title: { type: "string" },
                      creator_name: { type: "string" },
                      thumbnail_url: { type: "string" },
                      views: { type: "number" },
                      likes: { type: "number" },
                      shares: { type: "number" },
                      comments: { type: "number" },
                      hashtags: { type: "array", items: { type: "string" } },
                      posted_at: { type: "string" },
                      product_name: { type: "string" },
                    },
                    required: ["video_url", "title"],
                    additionalProperties: false,
                  },
                },
              },
              required: ["videos"],
              additionalProperties: false,
            },
          },
        }],
        tool_choice: { type: "function", function: { name: "extract_videos" } },
      }),
    });

    if (!response.ok) {
      console.error("AI video extraction failed:", response.status);
      return extractVideosFallback(markdown, sourceUrl);
    }

    const data = await response.json();
    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall) return extractVideosFallback(markdown, sourceUrl);

    const parsed = JSON.parse(toolCall.function.arguments);
    const videos: AIExtractedVideo[] = (parsed.videos || [])
      .filter((v: any) => v.video_url && /tiktok\.com\/@[\w.]+\/video\/\d+/.test(v.video_url))
      .map((v: any) => ({
        video_url: v.video_url,
        title: (v.title || "").substring(0, 120),
        creator_name: v.creator_name || extractCreatorFromUrl(v.video_url),
        thumbnail_url: v.thumbnail_url || null,
        views: typeof v.views === "number" ? v.views : null,
        likes: typeof v.likes === "number" ? v.likes : null,
        shares: typeof v.shares === "number" ? v.shares : null,
        comments: typeof v.comments === "number" ? v.comments : null,
        hashtags: Array.isArray(v.hashtags) ? v.hashtags.slice(0, 5) : [],
        posted_at: v.posted_at || null,
        product_name: v.product_name || null,
      }));

    console.log(`AI extracted ${videos.length} videos from ${sourceUrl}`);
    return videos;
  } catch (err) {
    console.error("AI video extraction error:", err);
    return extractVideosFallback(markdown, sourceUrl);
  }
}

function extractVideosFallback(content: string, sourceUrl: string): AIExtractedVideo[] {
  const videos: AIExtractedVideo[] = [];
  const tiktokUrls = (content + " " + sourceUrl).match(
    /https?:\/\/(?:www\.)?tiktok\.com\/@[\w.]+\/video\/\d+/g
  ) || [];

  const uniqueUrls = [...new Set(tiktokUrls)];
  for (const url of uniqueUrls.slice(0, 10)) {
    videos.push({
      video_url: url,
      title: `TikTok video by ${extractCreatorFromUrl(url) || "unknown"}`,
      creator_name: extractCreatorFromUrl(url),
      thumbnail_url: null,
      views: null,
      likes: null,
      shares: null,
      comments: null,
      hashtags: [],
      posted_at: null,
      product_name: null,
    });
  }
  return videos;
}

// ─── Google CSE Image Search ───

async function searchImageWithGoogleCSE(query: string): Promise<string | null> {
  const cseKey = Deno.env.get("GOOGLE_CSE_API_KEY");
  const cseCx = Deno.env.get("GOOGLE_CSE_CX");
  if (!cseKey || !cseCx) return null;

  try {
    const q = encodeURIComponent(query);
    const url = `https://www.googleapis.com/customsearch/v1?key=${cseKey}&cx=${cseCx}&q=${q}&searchType=image&num=3&imgSize=medium`;
    const res = await fetch(url);
    if (!res.ok) return null;

    const data = await res.json();
    const items = data.items || [];
    for (const item of items) {
      const link = item.link;
      if (link && /\.(jpg|jpeg|png|webp)/i.test(link) && !link.includes("placeholder")) {
        console.log(`Google CSE found thumbnail: ${link.substring(0, 80)}`);
        return link;
      }
    }
    if (items.length > 0 && items[0].link) return items[0].link;
    return null;
  } catch (err) {
    console.error("Google CSE search error:", err);
    return null;
  }
}

// ─── Utilities ───

async function downloadToStorage(supabase: any, supabaseUrl: string, imageUrl: string, folder: string): Promise<string | null> {
  try {
    const response = await fetch(imageUrl, { 
      headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" },
      redirect: "follow",
    });
    if (!response.ok) return null;

    const contentType = response.headers.get("content-type") || "image/jpeg";
    if (!contentType.startsWith("image/")) return null;
    
    const ext = contentType.includes("png") ? "png" : contentType.includes("webp") ? "webp" : "jpg";
    const fileName = `${folder}/${crypto.randomUUID()}.${ext}`;
    const blob = await response.arrayBuffer();
    
    if (blob.byteLength < 1000) return null;

    const { error } = await supabase.storage
      .from("scraped-media")
      .upload(fileName, blob, { contentType, upsert: false });

    if (error) {
      console.error("Storage upload error:", error.message);
      return null;
    }

    return `${supabaseUrl}/storage/v1/object/public/scraped-media/${fileName}`;
  } catch (err) {
    console.error("Image download error:", err);
    return null;
  }
}

function extractCreatorFromUrl(url: string): string | null {
  const match = url.match(/tiktok\.com\/@([\w.]+)/);
  return match ? `@${match[1]}` : null;
}

function calcScore(views: number, likes: number, shares: number): number {
  const v = Math.min(views / 5000000, 1) * 40;
  const l = Math.min(likes / 500000, 1) * 30;
  const s = Math.min(shares / 100000, 1) * 30;
  return Math.round((v + l + s) * 10) / 10;
}

function estimateRevenue(views: number, likes: number): number {
  return Math.round((views / 1000) * 0.03 + likes * 0.5);
}

function deduplicateVideos(videos: AIExtractedVideo[]): AIExtractedVideo[] {
  const seen = new Map<string, AIExtractedVideo>();
  for (const v of videos) {
    if (!seen.has(v.video_url)) {
      seen.set(v.video_url, v);
    }
  }
  return Array.from(seen.values());
}
