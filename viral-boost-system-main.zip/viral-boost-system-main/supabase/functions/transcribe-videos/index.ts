import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const lovableApiKey = Deno.env.get("LOVABLE_API_KEY");
    if (!lovableApiKey) {
      return new Response(
        JSON.stringify({ success: false, error: "LOVABLE_API_KEY not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const body = await req.json().catch(() => ({}));
    const videoId = body.video_id;
    const limit = body.limit || 10;

    if (videoId) {
      const { data: video, error } = await supabase
        .from("viral_videos")
        .select("*")
        .eq("id", videoId)
        .maybeSingle();

      if (error || !video) {
        return new Response(
          JSON.stringify({ success: false, error: "Video not found" }),
          { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const transcription = await generateTranscription(lovableApiKey, video);

      const { error: updateError } = await supabase
        .from("viral_videos")
        .update({ transcription })
        .eq("id", videoId);

      if (updateError) {
        console.error("Error saving transcription:", updateError);
      }

      return new Response(
        JSON.stringify({ success: true, transcription, video_id: videoId }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Batch transcription
    const { data: videos, error: fetchError } = await supabase
      .from("viral_videos")
      .select("*")
      .is("transcription", null)
      .order("trending_score", { ascending: false })
      .limit(limit);

    if (fetchError) {
      return new Response(
        JSON.stringify({ success: false, error: fetchError.message }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`Transcribing ${videos?.length || 0} videos`);

    let transcribedCount = 0;
    for (const video of videos || []) {
      try {
        const transcription = await generateTranscription(lovableApiKey, video);

        await supabase
          .from("viral_videos")
          .update({ transcription })
          .eq("id", video.id);

        transcribedCount++;
      } catch (err) {
        console.error(`Error transcribing video ${video.id}:`, err);
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        message: `Transcribed ${transcribedCount} of ${videos?.length || 0} videos`,
        transcribed_count: transcribedCount,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error in transcribe-videos:", error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

async function generateTranscription(
  apiKey: string,
  video: {
    title?: string | null;
    creator_name?: string | null;
    hashtags?: string[] | null;
    views?: number | null;
    likes?: number | null;
    product_name?: string | null;
  }
): Promise<string> {
  const prompt = `Você é um especialista em vídeos virais do TikTok Shop Brasil. Com base nas informações abaixo, gere uma análise estruturada do roteiro deste vídeo viral.

Responda EXATAMENTE neste formato JSON (sem markdown, sem code blocks, apenas o JSON puro):
{
  "gancho": "O gancho de atenção usado nos primeiros 3 segundos do vídeo para prender o espectador. Deve ser uma frase curta e impactante.",
  "dor": "A dor ou problema que o vídeo identifica no público-alvo. Qual frustração ou necessidade o criador explora.",
  "solucao": "A solução apresentada no vídeo, como o produto resolve o problema do espectador.",
  "descricao": "A transcrição completa do roteiro do vídeo em português brasileiro informal, com ganchos de atenção, demonstração do produto e call-to-action. Entre 150-250 palavras. Incluir emojis relevantes."
}

Informações do vídeo:
- Título: ${video.title || "Produto viral"}
- Criador: ${video.creator_name || "Criador TikTok"}
- Hashtags: ${(video.hashtags || []).join(", ")}
- Views: ${video.views || 0}
- Likes: ${video.likes || 0}
- Produto: ${video.product_name || "Produto em destaque"}

Responda APENAS com o JSON, sem nenhum texto adicional.`;

  const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "google/gemini-2.5-flash",
      messages: [{ role: "user", content: prompt }],
      max_tokens: 800,
      temperature: 0.7,
    }),
  });

  if (!response.ok) {
    throw new Error(`AI API error: ${response.status}`);
  }

  const data = await response.json();
  const content = data.choices?.[0]?.message?.content || "";
  
  // Clean any markdown code blocks if present
  const cleaned = content.replace(/```json\s*/g, "").replace(/```\s*/g, "").trim();
  
  // Validate it's valid JSON
  try {
    JSON.parse(cleaned);
    return cleaned;
  } catch {
    // Fallback: wrap plain text in structured format
    return JSON.stringify({
      gancho: "🔥 Olha isso!",
      dor: "Você precisa ver esse produto",
      solucao: "A solução perfeita para o seu dia a dia",
      descricao: content,
    });
  }
}
