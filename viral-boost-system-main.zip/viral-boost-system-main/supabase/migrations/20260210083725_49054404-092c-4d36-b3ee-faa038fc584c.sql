-- Add unique constraint on product_name for upsert support
ALTER TABLE public.viral_products ADD CONSTRAINT viral_products_product_name_key UNIQUE (product_name);

-- Allow edge functions (service role) to insert/update products and videos
-- The existing RLS policies use "true" for SELECT which is fine
-- Service role bypasses RLS, so no additional policies needed for edge functions
