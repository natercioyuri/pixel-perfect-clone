-- Add transcription column to viral_videos
ALTER TABLE public.viral_videos ADD COLUMN IF NOT EXISTS transcription text;

-- Add product_name denormalized for display
ALTER TABLE public.viral_videos ADD COLUMN IF NOT EXISTS product_name text;

-- Add video duration
ALTER TABLE public.viral_videos ADD COLUMN IF NOT EXISTS duration_seconds integer;

-- Add engagement rate column
ALTER TABLE public.viral_videos ADD COLUMN IF NOT EXISTS engagement_rate numeric;
