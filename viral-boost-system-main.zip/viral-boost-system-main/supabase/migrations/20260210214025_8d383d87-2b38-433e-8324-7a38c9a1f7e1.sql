
-- Create notifications table
CREATE TABLE public.notifications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID,
  type TEXT NOT NULL DEFAULT 'trending_product',
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  product_id UUID REFERENCES public.viral_products(id) ON DELETE SET NULL,
  trending_score NUMERIC,
  is_read BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- Global notifications (user_id IS NULL) are visible to all authenticated users
-- User-specific notifications are visible only to that user
CREATE POLICY "Users can view their notifications"
ON public.notifications FOR SELECT
USING (user_id IS NULL OR auth.uid() = user_id);

CREATE POLICY "Users can update own notifications"
ON public.notifications FOR UPDATE
USING (user_id IS NULL OR auth.uid() = user_id);

-- Only service role (edge functions) can insert
CREATE POLICY "Service role can insert notifications"
ON public.notifications FOR INSERT
WITH CHECK (true);

-- Index for faster queries
CREATE INDEX idx_notifications_created_at ON public.notifications(created_at DESC);
CREATE INDEX idx_notifications_is_read ON public.notifications(is_read) WHERE is_read = false;
