
-- Drop the overly permissive insert policy
DROP POLICY "Service role can insert notifications" ON public.notifications;

-- Edge functions use service_role key which bypasses RLS, so no INSERT policy needed for authenticated users
-- If we want admins to also insert:
CREATE POLICY "Admins can insert notifications"
ON public.notifications FOR INSERT
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- Also add delete for admins
CREATE POLICY "Admins can delete notifications"
ON public.notifications FOR DELETE
USING (has_role(auth.uid(), 'admin'::app_role));
