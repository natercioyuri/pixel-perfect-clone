
-- Create table to store daily ranking snapshots
CREATE TABLE public.product_ranking_history (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  product_id UUID NOT NULL REFERENCES public.viral_products(id) ON DELETE CASCADE,
  rank_position INTEGER NOT NULL,
  trending_score NUMERIC,
  snapshot_date DATE NOT NULL DEFAULT CURRENT_DATE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(product_id, snapshot_date)
);

ALTER TABLE public.product_ranking_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view ranking history"
ON public.product_ranking_history FOR SELECT
USING (true);

CREATE POLICY "Admins can manage ranking history"
ON public.product_ranking_history FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE INDEX idx_ranking_history_date ON public.product_ranking_history(snapshot_date DESC);
CREATE INDEX idx_ranking_history_product ON public.product_ranking_history(product_id, snapshot_date DESC);
