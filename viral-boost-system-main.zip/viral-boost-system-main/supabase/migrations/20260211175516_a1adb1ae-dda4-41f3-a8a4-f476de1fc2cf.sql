
-- Create storage bucket for scraped media
INSERT INTO storage.buckets (id, name, public) 
VALUES ('scraped-media', 'scraped-media', true)
ON CONFLICT (id) DO NOTHING;

-- Allow public read access
CREATE POLICY "Public read access for scraped media"
ON storage.objects FOR SELECT
USING (bucket_id = 'scraped-media');

-- Allow service role to upload (edge functions use service role)
CREATE POLICY "Service role upload for scraped media"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'scraped-media');
