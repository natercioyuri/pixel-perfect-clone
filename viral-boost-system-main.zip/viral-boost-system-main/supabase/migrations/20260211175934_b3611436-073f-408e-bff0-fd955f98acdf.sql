
-- Add unique constraint on video_url for upsert support
ALTER TABLE public.viral_videos ADD CONSTRAINT viral_videos_video_url_key UNIQUE (video_url);
